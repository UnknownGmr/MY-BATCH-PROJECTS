HOW TO USE:
simply type the name of the file that you want to run then hit enter make sure to have extention.

put the files u want quick accses to in the folder with the main.bat script in it.

